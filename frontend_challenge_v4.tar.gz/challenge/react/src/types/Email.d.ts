export type Email = {
  id: string
  from: string
  to: string[]
  subject: string
  datetime: string
}
