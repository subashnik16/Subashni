<script lang="ts">
  export let recipients
</script>
